*********** Instructions on how to run the demo program ************ 

In the folder, you will find the demo program - DEMO_tvcg.exe

0). The interface 
Execution of "DEMO_tvcg.exe" on a Windows system will show you the GUI. You can rotate the view direction with the left mouse button, and zoom in/out with the right mouse button.
The program will also show a console window to provide additional feedback about the processing steps taking place in the code.

1). Loading the dataset

Clicking on the "Load Seed" button will direct you to the "wrestling" folder, where the dataset and a set of *.seed files are provided. Select and open one of the seed files, e.g., "wrestling1.seed". The dataset will be loaded to the memory, and you will be able to see the seed pose-pair on the screen.

2). Perform sampling

On the bottom left of the interface, you will see two input boxes:
- "# of samples": enter the number of samples you wish to generate. 
- "# of threads": specify the number of CPU threads to be used for the sampling. 

Once you have provided these two numbers, press "Start sampling from here" to begin the sampling process. It is important to note that you will not be able to interact with the GUI until the sampling process has completed. However, feedback is still provided through the console window. The sampling process will require some time to complete. In our tests, the sampling speed is around 10 fps on an 4-Core 3.4GHz i7 CPU.


3). Watch the result

After the sampling is complete, you will be able to interact with the GUI again. Player controls are provided on the bottom which allow you to explore the pose-pair samples.

Please note that due to the nature of our sampling method, the pose-pair samples are not aligned with the world coordinate system. Therefore, you will need to rotate the view direction in order to view the pose-pairs properly.

To provide evidence to the validness of the current sample you are viewing, a set of related wrestling photos are retrieved and displayed on the right of the interface( see "screenshot.png" ).  You may also want to watch the annotation video "wresting.mp4" in the wrestling folder to perceive what are wrestling interactions.

4). Sampling restart

You can move the slider on the bottom to any one frame of pose-pair sample you like. Then press "Start sampling from here" to restart sampling from the frame.





